Zion Tech Hub registration dashboard

Open Zion_Tech_Hub_Registration_Analysis.pbip in Power BI Desktop. The project uses PBIR report files and a TMDL semantic model with one table: Registrations. The table contains 1318 cleaned rows from the supplied Cohort 9 and Cohort 10 exports.

The model stores the cleaned snapshot in an embedded Power Query #table expression for portability. The CSV beside this README is the refreshable cleaned extract for future loads.

Occupation was not captured in Cohort 9, so occupation analysis belongs to Cohort 10 only. Registration counts are the available conversion signal. Payment, spend, CAC and downstream enrollment fields were not supplied.
